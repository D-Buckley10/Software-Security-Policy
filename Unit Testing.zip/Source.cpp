// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL(); // Throws automatic failure
}

// Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // Add entry to collection
    add_entries(1);
    // Expect that collection has one entry in it
    EXPECT_EQ(collection->size(), 1);
    // Output entry amount in collection
    std::cout << "Collection Size: " << (int)collection->size() << std::endl;
}

//  Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // Add five entries to collection
    add_entries(5);
    // Output colleciton size to ensure 5 entries were added
    std::cout << "Collection size: " << (int)collection->size() << std::endl;
    // is the collection still empty? if not what must the size be?
    EXPECT_EQ(collection->size(), 5);

    
}

// TODO (COMPLETED): Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsMaxSizeGreaterThanZeroOneFiveTen) 
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    ASSERT_GE(collection->max_size(), collection->size()); // Runs test for collection size = 0
    add_entries(1); // Adds entry to collection; Collection = 1

    ASSERT_GE(collection->max_size(), collection->size()); // Runs test for colleciton size = 1
    add_entries(4); // Adds 4 entries to collection; Collection = 5

    ASSERT_GE(collection->max_size(), collection->size()); // Runs test for collection size = 5
    add_entries(5); // Adds 5 entries to collection; Collection = 10

    ASSERT_GE(collection->max_size(), collection->size()); // Runs test for collcetion size = 10
    std::cout << "Collection Max Size: " << (int)collection->max_size() << std::endl;
}

// TODO (COMPLETED): Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsCapacityGreaterThanZeroOneFiveTen)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    ASSERT_GE(collection->capacity(), collection->size()); // Runs test for collection = 0
    add_entries(1); // Adds entry to collection; Collection = 1

    ASSERT_GE(collection->capacity(), collection->size()); // Runs test for colleciton size = 1
    add_entries(4); // Adds 4 entries to collection; Collection = 5

    ASSERT_GE(collection->capacity(), collection->size()); // Runs test for collection size = 5
    add_entries(5); // Adds 5 entries to collection; Collection = 10

    ASSERT_GE(collection->capacity(), collection->size()); // Runs test for collcetion size = 10
    std::cout << "Collection Capacity: " << (int)collection->capacity() << std::endl;
}

// Create a test to verify resizing increases the collection
TEST_F(CollectionTest, DoesResizingIncreaseVectorSize)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    std::cout << "Collection Size: " << (int)collection->size() << std::endl;
    // Sets collection size to 10
    collection->resize(10);
    // Display collection size to ensure colleciton size has changed from 0 to 10
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; 
    // Sets collection size to 80
    collection->resize(80);
    // Display collection size to ensure colleciton size has changed from 20 to 80
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; 
    // Expect collection size to have 80 entries
    EXPECT_EQ(collection->size(), 80);
}

// Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, DoesResizingDecreaseVectorSize)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // Adds 75 entries into the collection
    add_entries(75); 
    // Display collection size to ensure colleciton size has 75 entries
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; 
    // Sets collection size to 25
    collection->resize(25); 
    // Display collection size to ensure colleciton size has changed from 50 to 25
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; 
    // Expect collection to have 25 entries
    EXPECT_EQ(collection->size(), 25);
}

// TODO (COMPLETED): Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, DoesResizingDecreaseVectorSizeToZero)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    add_entries(100); // Adds 100 entries into the collection
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; // Display collection size to ensure 100 entries have been added

    collection->resize(0); // Sets collection size to 0
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; // Display collection size to ensure size has changed from 100 to 0

    EXPECT_EQ(collection->size(), 0);
}

// Create a test to verify clear erases the collection
TEST_F(CollectionTest, DoesClearEraseCollection)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // Adds 100 entries into the collection
    add_entries(100); 
    // Display collection size to ensure 100 entries have been added
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; 
    // Clear collection with clear() function
    collection->clear();
    // Display collection size to ensure all 100 entries have been erased by the clear function
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; 
    // Verify test with EXPECT collection size = 0
    EXPECT_EQ(collection->size(), 0);
}

// TODO (COMPLETED): Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, DoesEraseBeginEndEraseCollection)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    std::cout << "Collection Size: " << (int)collection->size() << std::endl; // Ensure collection is empty

    add_entries(10);

    std::vector<int>::reverse_iterator rIt = collection->rbegin();
    int i = 0;
    for (rIt = collection->rbegin(); rIt != collection->rend(); ++rIt) {
        *rIt = ++i;
    }
    std::cout << "Collection contains: " << std::endl;
    for (std::vector<int>::iterator It = collection->begin(); It != collection->end(); ++It) {
        std::cout << ' ' << *It;
    }

    std::cout << std::endl;

    return;

    EXPECT_EQ(collection->size(), 0);
}

// TODO (COMPLETED): Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, DoesReserveOnlyChangeCapacityAndNotSize) 
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // Display both size and capacity to show that both are empty
    std::cout << "Colleciton Size: " << (int)collection->size() << std::endl;
    std::cout << "Collection Capacity: " << (int)collection->capacity() << std::endl;

    add_entries(10); // Add 10 entries
    collection->reserve(25); // Use reserve to alter capacity to 25

    EXPECT_EQ(collection->capacity(), 25);
    EXPECT_EQ(collection->size(), 10);

    std::cout << "Colleciton Size: " << (int)collection->size() << std::endl;
    std::cout << "Collection Capacity: " << (int)collection->capacity() << std::endl;
}

// Create a test to verify that exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutofRangeThrow)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // Output collection size to verify it's empty
    std::cout << "Colleciton Size: " << (int)collection->size() << std::endl;
    // Add 10 entries to collection
    add_entries(10);
    // Scan through collection for all entries
    for (unsigned i = 0; i < collection->size(); i++) {
        collection->at(i) = i;
    }
    // Create output loop to display all items in collection
    std::cout << "Collection contains:";
    for (unsigned i = 0; i < collection->size(); i++) {
        std::cout << ' ' << collection->at(i);
    }
    std::cout << std::endl;
    // Call out_of_range at position that's in range, failing the test
    ASSERT_THROW(collection->at(5), std::out_of_range); 
}

//  Create test to detect out of range throw
TEST_F(CollectionTest, PositiveOutofRangeThrow)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // Add 10 entries to colelction
    add_entries(10);
    // Output Collection size to verify proper entry count (10)
    std::cout << "Colleciton Size: " << (int)collection->size() << std::endl;
    // Attempt to find out of range entry, call out_of_range throw
    ASSERT_THROW(collection->at(50), std::out_of_range);
    // Print out message for out of throw
    std::cout << "Entry at pos 50 is out of range!" << std::endl;
}

TEST_F(CollectionTest, NegativeIsCollectionEmpty)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 1);
}

